# Copyright (c) 2018 Ultimaker B.V.


def getMetaData():
    return {}


def register(app):
    return {}
